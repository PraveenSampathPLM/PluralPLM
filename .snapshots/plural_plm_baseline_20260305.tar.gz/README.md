# PLM Project

Enterprise PLM starter platform for process industries (CPG, Chemicals, Tyre/Rubber, Polymers, Paints, Food & Beverage).

## Monorepo Structure

- `packages/frontend`: React 18 + TypeScript + Vite UI app
- `packages/backend`: Express + TypeScript + Prisma REST API
- `packages/shared`: Shared TS types
- `prisma/schema.prisma`: Data model
- `prisma/seed.ts`: Seed data

## Quick Start

1. `cp .env.example .env`
2. `make up`
3. `npm install`
4. `make migrate`
5. `make seed`
6. `make dev`

## Seed Users

All users use password: `Password@123`

- `admin@plm.local` (System Admin)
- `plm@plm.local` (PLM Admin)
- `chemist@plm.local` (Formulation Chemist)
- `qa@plm.local` (QA Manager)
- `reg@plm.local` (Regulatory Affairs)

## Initial API Surface

- `POST /api/auth/login`
- `GET/POST/PUT /api/items`
- `GET/POST /api/formulas`
- `GET /api/dashboard`

All non-auth endpoints require `Authorization: Bearer <token>`.
