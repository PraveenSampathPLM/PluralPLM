import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useContainerStore } from "@/store/container.store";
import { PluralLogo } from "@/components/plural-logo";
import { useAuthStore } from "@/store/auth.store";

const navItems = [
  { to: "/", label: "Dashboard" },
  { to: "/tasks", label: "My Tasks" },
  { to: "/items", label: "Materials & Recipes" },
  { to: "/formulas", label: "Formulation" },
  { to: "/bom", label: "BOMs" },
  { to: "/documents", label: "Documents" },
  { to: "/changes", label: "Changes" },
  { to: "/releases", label: "Releases" },
  { to: "/specifications", label: "Specifications" },
  { to: "/containers", label: "Containers" },
  { to: "/configuration", label: "Configuration" }
];

export function AppLayout(): JSX.Element {
  const location = useLocation();
  const navigate = useNavigate();
  const { selectedContainerId, setSelectedContainerId } = useContainerStore();
  const clearAuth = useAuthStore((state) => state.clearAuth);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const containers = useQuery({
    queryKey: ["layout-container-options"],
    queryFn: async () => (await api.get<{ data: Array<{ id: string; code: string; name: string }> }>("/containers")).data
  });
  const tasks = useQuery({
    queryKey: ["workflow-tasks-count"],
    queryFn: async () =>
      (
        await api.get<{
          data: Array<{ instanceId: string; title?: string; entityType?: string; entityId?: string; action?: string; state?: string }>;
        }>("/workflows/tasks")
      ).data,
    refetchInterval: 30000
  });
  const taskCount = tasks.data?.data?.length ?? 0;
  const readTaskIds = useMemo(() => {
    try {
      const stored = localStorage.getItem("plm_task_reads");
      return stored ? new Set<string>(JSON.parse(stored) as string[]) : new Set<string>();
    } catch {
      return new Set<string>();
    }
  }, [taskCount]);
  const unreadTasks = (tasks.data?.data ?? []).filter((task) => !readTaskIds.has(task.instanceId));
  const unreadCount = unreadTasks.length;
  useEffect(() => {
    if (!selectedContainerId) {
      return;
    }
    const exists = Boolean(containers.data?.data.some((container) => container.id === selectedContainerId));
    if (!exists && containers.data) {
      setSelectedContainerId("");
    }
  }, [containers.data, selectedContainerId, setSelectedContainerId]);

  useEffect(() => {
    if (!location.pathname.startsWith("/tasks")) {
      return;
    }
    const ids = (tasks.data?.data ?? []).map((task) => task.instanceId);
    if (!ids.length) {
      return;
    }
    localStorage.setItem("plm_task_reads", JSON.stringify(ids));
  }, [location.pathname, tasks.data?.data]);

  function markTaskRead(instanceId: string): void {
    const next = new Set(readTaskIds);
    next.add(instanceId);
    localStorage.setItem("plm_task_reads", JSON.stringify(Array.from(next)));
  }

  return (
    <div className="min-h-screen bg-mainbg">
      <aside className="fixed left-0 top-0 h-screen w-64 border-r border-slate-800/80 bg-sidebar px-4 py-5 text-slate-100 shadow-2xl shadow-slate-900/25">
        <PluralLogo />
        <nav className="mt-8 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`block rounded-lg px-3 py-2 text-sm transition ${
                location.pathname === item.to || (item.to !== "/" && location.pathname.startsWith(item.to))
                  ? "bg-gradient-to-r from-primary to-[#245e86] text-white"
                  : "text-slate-300 hover:bg-slate-800 hover:text-white"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <main className="pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-200/80 bg-white/95 px-6 backdrop-blur">
          <div>
            <p className="font-heading text-lg font-semibold tracking-tight text-slate-900">Plural PLM</p>
            <p className="text-xs text-slate-500">Product Lifecycle Platform</p>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={selectedContainerId}
              onChange={(event) => setSelectedContainerId(event.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs shadow-sm"
            >
              <option value="">All Accessible Containers</option>
              {containers.data?.data.map((container) => (
                <option key={container.id} value={container.id}>
                  {container.code} - {container.name}
                </option>
              ))}
            </select>
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotificationsOpen((prev) => !prev)}
                className="relative rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs"
              >
              <span className="flex items-center gap-2 text-slate-700">
                <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" className="text-slate-600">
                  <path
                    fill="currentColor"
                    d="M12 22a2.5 2.5 0 0 0 2.5-2.5h-5A2.5 2.5 0 0 0 12 22Zm7-6V11a7 7 0 0 0-5-6.7V3a2 2 0 1 0-4 0v1.3A7 7 0 0 0 5 11v5l-2 2v1h18v-1l-2-2Z"
                  />
                </svg>
                Notifications
              </span>
              {unreadCount > 0 ? (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] text-white">
                  {unreadCount}
                </span>
              ) : null}
              </button>
              {notificationsOpen ? (
                <div className="absolute right-0 mt-2 w-80 rounded-lg border border-slate-200 bg-white shadow-lg">
                  <div className="flex items-center justify-between border-b border-slate-100 px-3 py-2 text-xs text-slate-600">
                    <span>
                      Unread {unreadCount} / Total {taskCount}
                    </span>
                    <button
                      type="button"
                      className="text-xs text-primary"
                      onClick={() => {
                        const ids = (tasks.data?.data ?? []).map((task) => task.instanceId);
                        localStorage.setItem("plm_task_reads", JSON.stringify(ids));
                        setNotificationsOpen(false);
                        navigate("/tasks");
                      }}
                    >
                      View all
                    </button>
                  </div>
                  <div className="max-h-64 overflow-auto">
                    {tasks.isLoading ? (
                      <p className="px-3 py-3 text-xs text-slate-500">Loading tasks...</p>
                    ) : tasks.data?.data?.length ? (
                      tasks.data.data.slice(0, 5).map((task) => (
                        <button
                          key={task.instanceId}
                          type="button"
                          onClick={() => {
                            markTaskRead(task.instanceId);
                            setNotificationsOpen(false);
                            navigate(`/tasks/${task.instanceId}`);
                          }}
                          className="flex w-full flex-col gap-1 border-b border-slate-100 px-3 py-2 text-left text-xs hover:bg-slate-50"
                        >
                          <span className="font-medium text-slate-800">{task.title ?? "Workflow Task"}</span>
                          <span className="text-slate-500">
                            {task.entityType ?? "Item"} · {task.state ?? task.action ?? "Pending"}
                          </span>
                        </button>
                      ))
                    ) : (
                      <p className="px-3 py-3 text-xs text-slate-500">No tasks assigned.</p>
                    )}
                  </div>
                </div>
              ) : null}
            </div>
            <p className="text-xs text-slate-500">Cmd+K</p>
            <button
              type="button"
              onClick={() => {
                clearAuth();
                navigate("/login");
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-700"
            >
              Logout
            </button>
          </div>
        </header>
        <section className="p-6">
          <Outlet />
        </section>
      </main>
    </div>
  );
}
